import UIKit

// MARK: Задание 1

func justPrint() {
    print("Hello world")
}
justPrint()

func printHi(name: String) {
    print ("Hello, \(name)!")
}
printHi(name: "Misha")

func printName(_ name: String) -> String {
    "Hello, \(name)!"
}
let George = printName("George")
print(George)

// MARK: Задание 2

func countCharacters(_ name: String, _ surname: String) -> String {
    let user =  name + " " + surname
    let count = String(user.count)
    return count
}
let Ivan = countCharacters("Ivan", "Grozniy")
print(Ivan)

// MARK: Задание 3
func squaringANumber(int: Int) {
    print(int * int)
}
squaringANumber(int: 4)

// MARK: Задание 4
func circleArea(radius: Double) -> Double {
    let area =  3.14 * radius * radius
    return area
}
circleArea(radius: 15)

// MARK: Задание 5
func day(isDay: Bool) {
    if isDay == true {
        print("Now it is daytime")
    } else {
        print("Now it is nighttime")
    }
}
day(isDay: true)

func timeDay(time: Int) {
    if time >= 7 && time <= 24 {
        print("Now it is daytime")
    } else if  time > 0 && (time <= 6)  {
        print("Now it is nighttime")
    } else {
        print("Incorrect time")
    }
}
timeDay(time: 25)

// MARK: Задание 6
//Функция Выводит пору года
func seasons1(numberOfMounth: Int) {
    if numberOfMounth == 12 || numberOfMounth == 1 || numberOfMounth == 2 {
        print("Winter")
    } else if numberOfMounth >= 3 && numberOfMounth <= 5 {
        print("spring")
    } else if numberOfMounth >= 6 && numberOfMounth <= 8 {
        print( "summer")
    } else if numberOfMounth >= 9 && numberOfMounth <= 11 {
        print("autumn")
    } else {
        print("incorrect mounth")
    }
}

//Функция Возвращает пору года
func seasons2(numberOfMounth: Int) -> String{
    if numberOfMounth == 12 || numberOfMounth == 1 || numberOfMounth == 2 {
        "Winter"
    } else if numberOfMounth >= 3 && numberOfMounth <= 5 {
        "Spring"
    } else if numberOfMounth >= 6 && numberOfMounth <= 8 {
        "Summer"
    } else if numberOfMounth >= 9 && numberOfMounth <= 11 {
        "Autumn"
    } else {
        "Incorrect mounth"
    }
}
seasons1(numberOfMounth: 1)
print(seasons2(numberOfMounth: 9))

// MARK: Задание 8
func isPrime(_ num: Int, divisor: Int? = nil) -> Bool {
    guard num >= 0 && num <= 100 else {
        return false
    }
    if num < 2 {
        return false
    }
    let currentDivisor = divisor ?? 2
    if currentDivisor >= num {
        return true
    }
    if num % currentDivisor == 0 {
        return false
    }
    return isPrime(num, divisor: currentDivisor + 1)
}
print(isPrime(11))


// MARK: Задание 9
 func factorial(number: Int) -> Int{
    var array = [Int]()
     func factor(num: Int) {
        if num > 0 && num < 100 {
            array.append(num)
            return factor(num: num - 1)
        } else { print( "unknown")}
    }
    factor(num: number)
    let factor = array.reduce(1, *)
    return factor
}
print(factorial(number: 5))

// MARK: Задание 10
func fibonacci(number: Int) -> [Int] {
    var array = [1,1,0]
    print(array)
    while array.count < number + 1 {
        let newNum = array[0] + array[1]
        array.reverse()
        array.append(newNum)
        array.reverse()
    }
    
    array.reverse()
    return array
}


print(fibonacci(number: 10))

// MARK: Задание 11
func summForInt (number: Int) -> Int {
    let newNum = String(number)
    var summ = 0
    for i in newNum {
        summ = summ + (Int(String(i)) ?? 0)
    }
    return summ
}

print(summForInt(number: 2222))
