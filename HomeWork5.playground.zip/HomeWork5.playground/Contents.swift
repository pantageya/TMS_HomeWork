import UIKit
// MARK : Задание 1
enum Currency: String {
    case USD = "USD"
    case EUR = "EUR"
    case BLR = "BLR"
}
func getExchangeRate(from: Currency, to: Currency) -> Double? {
    switch (from, to) {
        
    case (.USD, .EUR):
        return 0.3273/0.2989
    case (.USD, .BLR):
        return 0.3273/1
    case (.EUR, .USD):
        return 0.2989/0.3273
    case (.EUR, .BLR):
        return 0.2989/1
    case (.BLR, .USD):
        return 1/0.3273
    case (.BLR, .EUR):
        return 1/0.2989
    default : return nil
    }
}
print(getExchangeRate(from: .BLR, to: .USD)!)
    
func convertCurrency(amount: Double, from: Currency, to: Currency) -> Double? {
    let rate = getExchangeRate(from: from, to: to)
    guard let rate = rate else {
        return nil
    }
    return amount * rate
}
print(convertCurrency(amount: 100, from: .BLR, to: .EUR)!)

// MARK : Задание 2

enum Grade : Int {
    case A = 100
    case B = 90
    case C = 80
    case D = 70
    case E = 60
}

func getLetterGrade(score: Int) -> Grade? {
    guard score > 0 && score <= 100 else {
        return nil
    }
        if score > 90 && score <= 100 {
            return .A
        } else if score > 80 && score <= 90 {
            return .B
        } else if score > 70 && score <= 80 {
            return .C
        } else if score > 60 && score <= 70 {
            return .D
        } else if score > 0 && score <= 60 {
            return .E
        } else {
            return nil
        }
    }

print(getLetterGrade(score: 77)) // Если ставлю опционал - значение не в деопозоне 0..100 - бьет краш. Если убираю опционал - все нормально, но при верном значении - криво выдает Оценку: Optional(__lldb_expr_183.Grade.C)
    

func printExamResult(name: String, score: Int) -> String {
    guard score > 0 && score <= 100 else {
        return "\(name) received an invalid score: \(score)"
    }
    let grade = getLetterGrade(score: score)
    return "\(name), your grade is: \(grade!), Score: \(score)"
}

print(printExamResult(name: "John", score: 78))
print(printExamResult(name: "Jack", score: 111))

